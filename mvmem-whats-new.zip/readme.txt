=== MVMEM What is New ===
Contributors: mattmcgiv
Donate link: http://antym.com
Requires at least: 3.0
Tested up to: 4.0
Stable tag: trunk
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Each user sees new comments and pages since the last time he/she visited.

== Description ==
Install this plugin and each user will have a constantly updated list of posts and comments they have not seen yet.  When a post or comment is viewed, it is marked off of the list.  When new posts and comments are published, they are added to each users list.